Beacon Console Bridge (Windows)
================================

Streams your Discord bot CMD window to your Vercel Beacon Console site.
The website is READ-ONLY (no typing / no remote shell).

1. Deploy BotConsole to Vercel first (see BotConsole-Vercel.zip / BotConsole/README.md).
2. Unzip this folder. Keep files together.
3. Prefer putting this folder next to smmod.py, OR use a full path for the command.
4. Double-click BeaconConsoleBridge.exe
5. Enter:
     - Website URL  (https://your-app.vercel.app)
     - Username
     - Password
     - Command to run  (default: py smmod.py   or your .exe path)
6. Leave this window open while the bot runs.
7. On your phone/laptop, open the Vercel URL and log in with the same username/password.

Config is saved as bridge_config.json next to the exe (do not share it).
